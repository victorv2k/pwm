//>>built
define(
"dijit/form/nls/nl/ComboBox", //begin v1.x content
({
		previousMessage: "Eerdere opties",
		nextMessage: "Meer opties"
})
//end v1.x content
);
