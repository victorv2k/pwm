//>>built
define(
//begin v1.x content
({
		previousMessage: "Scelte precedenti",
		nextMessage: "Altre scelte"
})
//end v1.x content
);
