//>>built
define(
"dijit/form/nls/zh-tw/ComboBox", //begin v1.x content
({
		previousMessage: "前一個選擇項",
		nextMessage: "其他選擇項"
})
//end v1.x content
);
