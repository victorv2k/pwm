//>>built
define(
"dijit/form/nls/sk/ComboBox", //begin v1.x content
({
		previousMessage: "Predchádzajúce voľby",
		nextMessage: "Ďalšie voľby"
})

//end v1.x content
);
