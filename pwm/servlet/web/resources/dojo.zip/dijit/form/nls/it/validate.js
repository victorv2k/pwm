//>>built
define(
"dijit/form/nls/it/validate", //begin v1.x content
({
	invalidMessage: "Il valore immesso non è valido.",
	missingMessage: "Questo valore è obbligatorio.",
	rangeMessage: "Questo valore non è compreso nell'intervallo."
})
//end v1.x content
);
