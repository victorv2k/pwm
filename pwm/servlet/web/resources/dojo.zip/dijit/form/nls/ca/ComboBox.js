//>>built
define(
"dijit/form/nls/ca/ComboBox", //begin v1.x content
({
		previousMessage: "Opcions anteriors",
		nextMessage: "Més opcions"
})

//end v1.x content
);
