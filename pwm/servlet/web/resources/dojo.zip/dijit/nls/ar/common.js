//>>built
define(
"dijit/nls/ar/common", //begin v1.x content
({
	buttonOk: "حسنا",
	buttonCancel: "الغاء",
	buttonSave: "حفظ",
	itemClose: "اغلاق"
})
//end v1.x content
);
