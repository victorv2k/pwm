//>>built
define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annullér",
	buttonSave: "Gem",
	itemClose: "Luk"
})
//end v1.x content
);
