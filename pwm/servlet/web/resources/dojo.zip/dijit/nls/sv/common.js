//>>built
define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Avbryt",
	buttonSave: "Spara",
	itemClose: "Stäng"
})
//end v1.x content
);
