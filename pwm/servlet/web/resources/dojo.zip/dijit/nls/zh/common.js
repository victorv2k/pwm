//>>built
define(
"dijit/nls/zh/common", //begin v1.x content
({
	buttonOk: "确定",
	buttonCancel: "取消",
	buttonSave: "保存",
	itemClose: "关闭"
})
//end v1.x content
);
