//>>built
define(
//begin v1.x content
({
	loadingState: "Nalaganje ...",
	errorState: "Oprostite, prišlo je do napake."
})
//end v1.x content
);
