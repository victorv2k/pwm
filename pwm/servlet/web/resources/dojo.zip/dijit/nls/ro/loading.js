//>>built
define(
"dijit/nls/ro/loading", //begin v1.x content
({
	loadingState: "Încărcare...",
	errorState: "Ne pare rău, a apărut o eroare "
})

//end v1.x content
);
