//>>built
define(
"dijit/nls/nl/loading", //begin v1.x content
({
	loadingState: "Bezig met laden...",
	errorState: "Er is een fout opgetreden"
})
//end v1.x content
);
